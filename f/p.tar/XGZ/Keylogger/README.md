# py-keylogger
A Simple Keylogger for Linux application written in Python using the pyxhook module which is an implementation of pyhook module (for Windows OS). 

<h3>Requires:</h3> 
python-xlib

<h3>Installation & Tutorial:</h3><a href="http://www.techinfected.net/2015/10/how-to-make-simple-basic-keylogger-in-python-for-linux.html">Visit this LINK</a>
