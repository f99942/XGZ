from OpenSSL import SSL  
import socket  
import os  
import sys

print '''
        	(_)_(_)
                 (o o)
                ==\o/==
        	''' 

HOST = '192.168.47.144'  
PORT = 6116
ADDRESS = (HOST, PORT)

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)  
ctx = SSL.Context(SSL.SSLv23_METHOD)  
ctx.use_certificate_file('client.pem')  
sslSock = SSL.Connection(ctx, sock)  
sslSock.connect(ADDRESS)  
def main():  
        try:
            cmd = raw_input('$ ')
            sslSock.sendall(cmd)
            data = sslSock.recv(66384)
            print data
        except KeyboardInterrupt:
            sslSock.close()
            sys.exit(0)

while True:  
   main()
